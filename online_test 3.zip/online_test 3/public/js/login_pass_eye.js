//const XOAuth2 = require("nodemailer/lib/xoauth2");

//User Login Password Input Eye
function togglePassword()
{
    $(".eye").toggleClass("fa-eye").toggleClass("fa-eye-slash");
    var input = $(".eye").parent().find("input");
     if(input.attr("type")=="password")
     {
         input.attr("type","text");
     }
     else
     {
         input.attr("type","password");
     }
}

i=0;
r=0;
x=0;
qno=0;
var mydata = {};

// function getdata(){
//     $.ajax({
//         url : '/examPost',
//         method : 'post',
//         success : function(data){
            
//             showQuestion(data,qno);
//         },
//         error:function(error)
//         {
//             alert("Error He ");
//         }
//     });
// }

// function showQuestion(arr,x)
// {   
//     alert(JSON.stringify(arr));  
// }

function nextQuestion()
{
    qno++;
    getdata();
}

function myquestion(x)
{
    qno=x-1;
    getdata();
}

function clearData()
{
    $("input:radio[name=rad]:checked")[0].checked = false; 

}

function mark(questionnumber,correctanswer,givenanswer)
{
    alert(op1.txtContent);

    row=[questionnumber,correctanswer,givenanswer]; 
    result=[];
    result.push(row);
    alert(JSON.stringify(result));
}
//Exam Timer
const COUNTER_KEY = 'my-counter';

        function countDown(i, callback) {
        timer = setInterval(function() {
            minutes = parseInt(i / 60, 10);
            seconds = parseInt(i % 60, 10);

            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            document.getElementById("time").innerHTML = minutes + ":" + seconds;

            if ((i--) > 0) {
            window.sessionStorage.setItem(COUNTER_KEY, i);
            } else {
            window.sessionStorage.removeItem(COUNTER_KEY);
            clearInterval(timer);
            window.location.href="http://127.0.0.1:3000/finish";
            callback();
            }
        }, 1000);
        }
        window.onload = function() {
        var countDownTime = window.sessionStorage.getItem(COUNTER_KEY) || 60 * 5;
        countDown(countDownTime, function() {
            $('#time').modal('show');
        });
        };
//Exam Timer Ends

//---------- Unrequired Code ----------
// function removePrebox()
// {
//     myid="ques_slide" + r;
//     $("#"+myid).remove();
//     r++;
// }

// function createboxNext(mydata)
// {
//     myid="ques_slide"+i;
//     // myrr="card-body" + i;
//     fff = JSON.parse(mydata);
//     for(x=1;x<fff.lenght;x++);
//         $("#myrow").append("<div class='ques_slide' id='" + myid + "'></div>");
//         $("#" + myid ).append("<div class='m-2 fw-bolder border-bottom' id='question_no'> Question No.</div>");
//         $("#question_no" ).append("<span> "+ fff[i]['questionnumber'] +"</span>");

//         $("#" + myid ).append("<div class='ps-2' id='question'>  "+ fff[i]['question'] +" </div>");
//         $("#question").append("<ul class='list-unstyled ms-2' id='ul'> </ul>");
//         $("#ul").append("<li id='lia'></li>");
//         $("#lia").append("<input type='radio' name='opt' value=''>");
//         $("#lia").append("<span class='ms-2'>(A) "+ fff[i]['a'] +"</span>");

//         $("#ul").append("<li id='lib'></li>");
//         $("#lib").append("<input type='radio' name='opt' value=''>");
//         $("#lib").append("<span class='ms-2'>(B) "+ fff[i]['b'] +"</span>");

//         $("#ul").append("<li id='lic'></li>");
//         $("#lic").append("<input type='radio' name='opt' value=''>");
//         $("#lic").append("<span class='ms-2'>(C) "+ fff[i]['c'] +"</span>");

//         $("#ul").append("<li id='lid'></li>");
//         $("#lid").append("<input type='radio' name='opt' value=''>");
//         $("#lid").append("<span class='ms-2'>(D) "+ fff[i]['d'] +"</span>");
//     if(i<=3)
//     i++;
//     else
//     $('#sm3').attr('disabled', true);
// }

// function clearData()
// {
//     alert("yea");
//     $('#sm2 input[type="radio":checked]').each(function(){
//         $(this).checked = false;  
//     });
// }

// function nextQuestion()
// {
//     removePrebox(mydata);
//     createboxNext(mydata);
// }

// function number(x)
// {
//    i=x;
//    removePrebox(mydata);
//    createboxNext(mydata);

// }
// -------- Unrequired Code Ends ----------